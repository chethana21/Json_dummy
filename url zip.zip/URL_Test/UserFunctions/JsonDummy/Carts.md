Carts

User Functions - If we the URL need to check for each user how many products are there like ID, Title, quantity, price for each products   https://dummyjson.com/carts
Test Functions - Need to check is it the ID is same and the Title quantity price 

User Functions - If we give ID it will print the cart details in the User
Test Functions - Need to check is it the same USER ID       https://dummyjson.com/carts/1
                 Details of the Product - Name, quantity, price

User Functions - add the products to cart need to give the User id & title, quantity 
Test Functions - need to check whether the id is present
                 Check whether the product is been added

User Functions - update the products to cart need to give the USER ID & product id, quanntity
Test Functions - need to go to USER ID
                 need to go to update function and check whether is it updated


https://dummyjson.com/docs/users

User Functions - we can get all the user details
Test function - total numbers of user are there

User Functions - get all the male & female count based on gender key
Test function - check whether the id is matching with the key or not

User Function - get all the details of company or address of specify city name example Nashville
Test function - need to check whether the id, f+l name, email is matching or not

User Function - get data based on deparament also example marketing & count
Test function - need to check whether the id, f+l name, email is matching or not