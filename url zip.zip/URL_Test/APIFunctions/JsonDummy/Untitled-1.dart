<Response [404]> <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Error</title>
</head>
<body>
<pre>Cannot POST /carts</pre>
</body>
</html>
 <bound method Response.json of <Response [404]>>
POST request error: 404 Client Error: Not Found for url: https://dummyjson.com/carts
({}, False)
({'id': 3, 'products': [], 'total': 0, 'discountedTotal': 0, 'userId': 63, 'totalProducts': 0, 'totalQuantity': 0}, False)
({'id': 7, 'products': [{'id': 61, 'title': 'Leather Straps Wristwatch', 'price': 120, 'quantity': 1, 'total': 120, 'discountPercentage': 7.14, 'discountedPrice': 111, 'thumbnail': 'https://i.dummyjson.com/data/products/61/thumbnail.jpg'}, {'id': 80, 'title': 'Chain Pin Tassel Earrings', 'price': 45, 'quantity': 2, 'total': 90, 'discountPercentage': 17.75, 'discountedPrice': 74, 'thumbnail': 'https://i.dummyjson.com/data/products/80/thumbnail.jpg'}, {'id': 99, 'title': 'American Vintage Wood Pendant Light', 'price': 46, 'quantity': 3, 'total': 138, 'discountPercentage': 8.84, 'discountedPrice': 126, 'thumbnail': 'https://i.dummyjson.com/data/products/99/thumbnail.jpg'}, {'id': 14, 'title': 'Non-Alcoholic Concentrated Perfume Oil', 'price': 120, 'quantity': 1, 'total': 120, 'discountPercentage': 15.6, 'discountedPrice': 101, 'thumbnail': 'https://i.dummyjson.com/data/products/14/thumbnail.jpg'}, {'id': 48, 'title': 'Women Strip Heel', 'price': 40, 'quantity': 3, 'total': 120, 'discountPercentage': 10.83, 'discountedPrice': 107, 'thumbnail': 'https://i.dummyjson.com/data/products/48/thumbnail.jpg'}], 'total': 588, 'discountedTotal': 519, 'userId': 56, 'totalProducts': 5, 'totalQuantity': 10, 'isDeleted': True, 'deletedOn': '2023-11-24T05:20:59.618Z'}, False)
(['smartphones', 'laptops', 'fragrances', 'skincare', 'groceries', 'home-decoration', 'furniture', 'tops', 'womens-dresses', 'womens-shoes', 'mens-shirts', 'mens-shoes', 'mens-watches', 'womens-watches', 'womens-bags', 'womens-jewellery', 'sunglasses', 'automotive', 'motorcycle', 'lighting'], 200)
({'products': [{'id': 6, 'title': 'MacBook Pro', 'description': 'MacBook Pro 2021 with mini-LED display may launch between September, November', 'price': 1749, 'discountPercentage': 11.02, 'rating': 4.57, 'stock': 83, 'brand': 'Apple', 'category': 'laptops', 'thumbnail': 'https://i.dummyjson.com/data/products/6/thumbnail.png', 'images': ['https://i.dummyjson.com/data/products/6/1.png', 'https://i.dummyjson.com/data/products/6/2.jpg', 'https://i.dummyjson.com/data/products/6/3.png', 'https://i.dummyjson.com/data/products/6/4.jpg']}, {'id': 7, 'title': 'Samsung Galaxy Book', 'description': 'Samsung Galaxy Book S (2020) Laptop With Intel Lakefield Chip, 8GB of RAM Launched', 'price': 1499, 'discountPercentage': 4.15, 'rating': 4.25, 'stock': 50, 'brand': 'Samsung', 'category': 'laptops', 'thumbnail': 'https://i.dummyjson.com/data/products/7/thumbnail.jpg', 'images': ['https://i.dummyjson.com/data/products/7/1.jpg', 'https://i.dummyjson.com/data/products/7/2.jpg', 'https://i.dummyjson.com/data/products/7/3.jpg', 'https://i.dummyjson.com/data/products/7/thumbnail.jpg']}, {'id': 8, 'title': 'Microsoft Surface Laptop 4', 'description': 'Style and speed. Stand out on HD video calls backed by Studio Mics. Capture ideas on the vibrant touchscreen.', 'price': 1499, 'discountPercentage': 10.23, 'rating': 4.43, 'stock': 68, 'brand': 'Microsoft Surface', 'category': 'laptops', 'thumbnail': 'https://i.dummyjson.com/data/products/8/thumbnail.jpg', 'images': ['https://i.dummyjson.com/data/products/8/1.jpg', 'https://i.dummyjson.com/data/products/8/2.jpg', 'https://i.dummyjson.com/data/products/8/3.jpg', 'https://i.dummyjson.com/data/products/8/4.jpg', 'https://i.dummyjson.com/data/products/8/thumbnail.jpg']}, {'id': 9, 'title': 'Infinix INBOOK', 'description': 'Infinix Inbook X1 Ci3 10th 8GB 256GB 14 Win10 Grey – 1 Year Warranty', 'price': 1099, 'discountPercentage': 11.83, 'rating': 4.54, 'stock': 96, 'brand': 'Infinix', 'category': 'laptops', 'thumbnail': 'https://i.dummyjson.com/data/products/9/thumbnail.jpg', 'images': ['https://i.dummyjson.com/data/products/9/1.jpg', 'https://i.dummyjson.com/data/products/9/2.png', 'https://i.dummyjson.com/data/products/9/3.png', 'https://i.dummyjson.com/data/products/9/4.jpg', 'https://i.dummyjson.com/data/products/9/thumbnail.jpg']}, {'id': 10, 'title': 'HP Pavilion 15-DK1056WM', 'description': 'HP Pavilion 15-DK1056WM Gaming Laptop 10th Gen Core i5, 8GB, 256GB SSD, GTX 1650 4GB, Windows 10', 'price': 1099, 'discountPercentage': 6.18, 'rating': 4.43, 'stock': 89, 'brand': 'HP Pavilion', 'category': 'laptops', 'thumbnail': 'https://i.dummyjson.com/data/products/10/thumbnail.jpeg', 'images': ['https://i.dummyjson.com/data/products/10/1.jpg', 'https://i.dummyjson.com/data/products/10/2.jpg', 'https://i.dummyjson.com/data/products/10/3.jpg', 'https://i.dummyjson.com/data/products/10/thumbnail.jpeg']}], 'total': 5, 'skip': 0, 'limit': 5}, 200)
({'products': [{'id': 1, 'title': 'iPhone 9', 'description': 'An apple mobile which is nothing like apple', 'price': 549, 'discountPercentage': 12.96, 'rating': 4.69, 'stock': 94, 'brand': 'Apple', 'category': 'smartphones', 'thumbnail': 'https://i.dummyjson.com/data/products/1/thumbnail.jpg', 'images': ['https://i.dummyjson.com/data/products/1/1.jpg', 'https://i.dummyjson.com/data/products/1/2.jpg', 'https://i.dummyjson.com/data/products/1/3.jpg', 'https://i.dummyjson.com/data/products/1/4.jpg', 'https://i.dummyjson.com/data/products/1/thumbnail.jpg']}], 'total': 1, 'skip': 0, 'limit': 1}, 200)
({'carts': [{'id': 19, 'products': [{'id': 43, 'title': 'frock gold printed', 'price': 600, 'quantity': 3, 'total': 1800, 'discountPercentage': 15.55, 'discountedPrice': 1520, 'thumbnail': 'https://i.dummyjson.com/data/products/43/thumbnail.jpg'}, {'id': 77, 'title': 'Rose Ring', 'price': 100, 'quantity': 3, 'total': 300, 'discountPercentage': 3.22, 'discountedPrice': 290, 'thumbnail': 'https://i.dummyjson.com/data/products/77/thumbnail.jpg'}, {'id': 50, 'title': 'Women Shoes', 'price': 36, 'quantity': 3, 'total': 108, 'discountPercentage': 16.87, 'discountedPrice': 90, 'thumbnail': 'https://i.dummyjson.com/data/products/50/thumbnail.jpg'}, {'id': 31, 'title': 'Mornadi Velvet Bed', 'price': 40, 'quantity': 2, 'total': 80, 'discountPercentage': 17, 'discountedPrice': 66, 'thumbnail': 'https://i.dummyjson.com/data/products/31/thumbnail.jpg'}, {'id': 75, 'title': 'Seven Pocket Women Bag', 'price': 68, 'quantity': 3, 'total': 204, 'discountPercentage': 14.87, 'discountedPrice': 174, 'thumbnail': 'https://i.dummyjson.com/data/products/75/thumbnail.jpg'}], 'total': 2492, 'discountedTotal': 2140, 'userId': 5, 'totalProducts': 5, 'totalQuantity': 14}], 'total': 1, 'skip': 0, 'limit': 1}, 200)

"Keyword name for getting data": {
    "Apple":{ "products": [{
    "id": 1,
    "title": "iPhone 9",
    "description": "An apple mobile which is nothing like apple",
    "price": 549,
    "discountPercentage": 12.96,
    "rating": 4.69,
    "stock": 94,
    "brand": "Apple",
    "category": "smartphones",
    "thumbnail": "https://i.dummyjson.com/data/products/1/thumbnail.jpg",
    "images": [
        "https://i.dummyjson.com/data/products/1/1.jpg",
        "https://i.dummyjson.com/data/products/1/2.jpg",
        "https://i.dummyjson.com/data/products/1/3.jpg",
        "https://i.dummyjson.com/data/products/1/4.jpg",
        "https://i.dummyjson.com/data/products/1/thumbnail.jpg"
    ]}],"total": 1,
    "skip": 0,
    "limit": 1}
}
}